# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
from sklearn.mixture import GaussianMixture

# Reading the data from csv file
df = pd.read_csv("2020_em_clustering.csv", sep=',', header=None)
df = df.transpose()

# Defining the number of clusters
kmeans = KMeans(n_clusters=2)

# Fitting the model
kmeans.fit(df)

# Predicting the clusters
predictions = kmeans.predict(df)

# Plotting the clusters
plt.scatter(df.iloc[:,0], [i for i in range(df.shape[0])], c=predictions)
plt.xlabel("Position")
plt.ylabel("Classification")
plt.show()

# Reading the data from csv file
df = pd.read_csv("2020_em_clustering.csv", sep=',', header=None)
df = df.transpose()

# Defining the number of clusters
em = GaussianMixture(n_components=2)

# Fitting the model,
"""
Fitting the model: The fit method is used to fit the EM algorithm to the data.
This step involves iteratively estimating the parameters of the Gaussian distribution for each cluster until convergence.
"""
em.fit(df)
predictions = em.predict(df)

# Plotting the clusters
plt.scatter(df.iloc[:,0], [i for i in range(df.shape[0])], c=predictions)
plt.xlabel("position")
plt.ylabel("Classification")
plt.show()

